# Service-SMS 📱

## Content

1. [Endpoints](#endpunkte)
    1. [sendSms](#sendsms)
    2. [getStats](#getstats)
    3. [createApp](#createapp)

### For every request, the application token must be stored in the header as an x-api key.

## 1. Endpunkte 📥 <a name="endpunkte"></a>

### 1. sendSMS 🚀 <a name="sendsms"></a>

| Protected | Master Protected
| ----------- | ----------- |
| ✔  | ❌ |

#### Endpoint:

```
POST /send-sms
```
#### Parameters:

| name | type | requiered | default Value | info
| ----------- | ----------- | ----------- | ----------- | ----------- |
| from | string | ✔ | - | The sender number
| to | string | ✔ | - | The recipient number
| message | string | ✔ | - | The recipient number
| originator | string | ❌ | - | Originator replaces the from field if specified. Only originators who are approved for the user can be selected



#### Example request:
```
{
    "from": "0176XXXXXX",
    "to": "0176XXXXXX",
    "message": "Test",
    "originator": "Codeanker"
}
```

#### Example response:
```
{
    "jobId": "1",
    "messageLengthNotice": "After converting the special characters, the message length is 4 characters and is sent in 1 SMS",
    "numberOfSmsSent": 1
}
```
-----
### 2. getStats 📊 <a name="getstats"></a>

| Protected | Master Protected
| ----------- | ----------- |
| ✔  | ❌ |

#### Endpoint:
```
GET /get-stats
```
#### Parameters:

| name | type | requiered | default Value | info
| ----------- | ----------- | ----------- | ----------- | ----------- |
| from | string | ✔ | - | Start date
| to | string | ❌ | current Date | End date, if not specified, the current date is chosen

#### Example request:
```
{
    "from": "12.21.2023",
    "to": "12.23.2023"
}
```

#### Example response:
```
{
    "from": "2023-12-20T23:00:00.000Z",
    "to": "2023-12-22T23:00:00.000Z",
    "totalMessagesCount": 1,
    "sentMessagesCount": 1,
    "pendingMessagesCount": 0
}
```

----

### 3. createApp ✨ <a name="createapp"></a>

| Protected | Master Protected
| ----------- | ----------- |
| ✔  | ✔ |

#### Endpoint:
```
POST /get-stats
```
#### Parameters:

| name | type | requiered | default Value | info
| ----------- | ----------- | ----------- | ----------- | ----------- |
| name | string | ✔ | - | Name of the application
| isMaster | boolean | ❌ | FALSE | Decides whether the app should have master access
| originator | Array<{ name: string; approved: boolean }> | ❌ | [] | Indicate originators and whether they are approved
| type | string ("DEV", "PROD") | ❌ | DEV | Application type

#### Example request:
```
{
    "name": "newApp",
    "originator": [{"name": "Test", "approved": false}],
    "type": "PROD",
    "isMaster": true
}
```

#### Example response:
```
{
    "token": "49e22c54-a8d9-49c8-b382-0b5d64bbacfd",
    "name": "newApp",
    "isMaster": true,
    "originator": [
        {
            "name": "Test",
            "approved": false
        }
    ],
    "type": "PROD"
}
```
