export default class PublicError extends Error {
  constructor(message?: string) {
    super(message)
    this.name = 'PublicError'
  }
}
