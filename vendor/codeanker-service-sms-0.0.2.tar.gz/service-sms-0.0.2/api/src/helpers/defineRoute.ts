import type { Context } from 'koa'
import { z } from 'zod'
import type { ZodOpenApiOperationObject } from 'zod-openapi'

import { authenticate, type AuthenticationResult } from '../authentication'
import { masterAuthenticate, type MasterAuthenticationResult } from '../masterAuthentication'

import PublicError from './PublicError'

export type RouteMethods = 'post' | 'get' | 'put' | 'delete'

type AnyZodObject = z.ZodObject<any, any>

type RouteConfig<TBody extends AnyZodObject, TResult extends AnyZodObject, TParams extends AnyZodObject> = {
  method: RouteMethods
  path: string
  id: string
  summary: string
  description: string
  bodySchema?: TBody
  paramsSchema?: TParams
  resultSchema: TResult
} & (
  | ProtetedRoute<TBody, TResult, TParams>
  | MasterRoute<TBody, TResult, TParams>
  | UnprotectedRoute<TBody, TResult, TParams>
)

type ProtetedRoute<TBody extends AnyZodObject, TResult extends AnyZodObject, TParams extends AnyZodObject> = {
  protected: true
  masterProtected: false | undefined
  handler: (handlerContext: {
    body: z.infer<TBody>
    params: z.infer<TParams>
    auth: AuthenticationResult
    context: Context
  }) => Promise<z.infer<TResult>>
}

type UnprotectedRoute<TBody extends AnyZodObject, TResult extends AnyZodObject, TParams extends AnyZodObject> = {
  protected: false | undefined
  masterProtected: false | undefined
  handler: (handlerContext: { body: z.infer<TBody>; params: z.infer<TParams> }) => Promise<z.infer<TResult>>
}

type MasterRoute<TBody extends AnyZodObject, TResult extends AnyZodObject, TParams extends AnyZodObject> = {
  protected: true
  masterProtected: true
  handler: (handlerContext: {
    body: z.infer<TBody>
    params: z.infer<TParams>
    auth: MasterAuthenticationResult
  }) => Promise<z.infer<TResult>>
}

export function defineRoute<TBody extends AnyZodObject, TResult extends AnyZodObject, TParams extends AnyZodObject>(
  routeConfig: RouteConfig<TBody, TResult, TParams>
) {
  return routeConfig
}

export function toKoaRoute<TBody extends AnyZodObject, TResult extends AnyZodObject, TParams extends AnyZodObject>(
  routeConfig: RouteConfig<TBody, TResult, TParams>
) {
  const bodySchema = routeConfig.bodySchema ?? z.strictObject({})
  const paramsSchema = routeConfig.paramsSchema ?? z.strictObject({})
  return async function (context: Context) {
    try {
      const body = bodySchema.parse(context.request.body)
      let result: z.infer<TResult>
      const params = paramsSchema.parse(context.params)
      if (routeConfig.protected || routeConfig.masterProtected) {
        const auth = routeConfig.masterProtected ? await masterAuthenticate(context) : await authenticate(context)
        result = await routeConfig.handler({ body, params, auth, context })
      } else {
        result = await routeConfig.handler({ body, params })
      }
      context.body = routeConfig.resultSchema.parse(result)
    } catch (error: any) {
      console.error(error)
      context.status = 500
      if (error instanceof PublicError) {
        context.body = { message: error.message }
      }
    }
  }
}

export function toOpenApiRoute(routeConfig: RouteConfig<any, any, any>): ZodOpenApiOperationObject {
  return {
    operationId: routeConfig.id,
    summary: routeConfig.summary,
    description: routeConfig.description,
    security: routeConfig.protected ? [{ ApiKeyAuth: [] }] : undefined,
    requestParams: {
      path: routeConfig.paramsSchema,
    },
    requestBody: {
      content: {
        'application/json': {
          schema: routeConfig.bodySchema,
        },
      },
    },
    responses: {
      '200': {
        description: 'Success',
        content: {
          'application/json': {
            schema: routeConfig.resultSchema,
          },
        },
      },
    },
  }
}

export function validateUniqueRoutes(routes: RouteConfig<any, any, any>[]) {
  const ids = routes.map((route) => route.id)
  const uniqueIds = new Set(ids)
  if (ids.length !== uniqueIds.size) {
    throw new Error('Duplicate route ids')
  }
  const pathsAndMethods = routes.map((route) => `${route.method} ${route.path}`)
  const uniquePathsAndMethods = new Set(pathsAndMethods)
  if (pathsAndMethods.length !== uniquePathsAndMethods.size) {
    throw new Error('Duplicate route paths and methods')
  }
}
