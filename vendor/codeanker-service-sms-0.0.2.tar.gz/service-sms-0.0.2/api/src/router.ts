import Router from '@koa/router'

import { toKoaRoute } from './helpers/defineRoute'
import { routes } from './routes/_routes'

const router = new Router()

routes.forEach((route) => {
  router[route.method](route.path, toKoaRoute(route))
})

export { router }
