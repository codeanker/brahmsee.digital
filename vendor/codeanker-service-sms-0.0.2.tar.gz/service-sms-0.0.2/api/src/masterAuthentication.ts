import type { application } from '@prisma/client'
import { NotFoundError } from '@prisma/client/runtime'
import type { Context } from 'koa'

import prisma from './prisma'
import { z } from './zod'

const headersSchema = z.object({
  'x-api-key': z.string(),
})

export type MasterAuthenticationResult = { application: application }

export async function masterAuthenticate(context: Context) {
  const { 'x-api-key': apiKey } = headersSchema.parse(context.request.headers)

  const application = await prisma.application.findUniqueOrThrow({
    where: {
      token: apiKey,
    },
  })

  if (!application.isMaster) throw new NotFoundError('No application found error')

  return { application }
}
