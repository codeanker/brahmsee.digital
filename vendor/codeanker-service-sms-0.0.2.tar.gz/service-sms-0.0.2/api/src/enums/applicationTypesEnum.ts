export default {
  DEV: { api: 'DEV', human: 'development' },
  PROD: { api: 'PROD', human: 'production' },
}
