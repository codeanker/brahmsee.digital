export default {
  ZIRKUMFLEX: { api: '^', human: '%1B%14' },
  BRACE_OPEN: { api: '{', human: '%1B%28' },
  BRACE_CLOSE: { api: '}', human: '%1B%29' },
  SLASH: { api: '/', human: '%1B%2F' },
  SQUARE_BRACKET_OPEN: { api: '[', human: '%1B%3C' },
  SQUARE_BRACKET_CLOSE: { api: ']', human: '%1B%3E' },
  TILDE: { api: '~', human: '%1B%3D' },
  PIPE: { api: '|', human: '%1B%40' },
  EURO: { api: '€', human: '%1B%65' },
}
