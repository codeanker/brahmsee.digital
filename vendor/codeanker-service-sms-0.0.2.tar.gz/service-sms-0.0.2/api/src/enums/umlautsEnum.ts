export default {
  ä: { api: 'ä', human: '%E4' },
  ö: { api: 'ö', human: '%F6' },
  ü: { api: 'ü', human: '%FC' },
  Ä: { api: 'Ä', human: '%DF' },
  Ö: { api: 'Ö', human: '%D6' },
  Ü: { api: 'Ü', human: '%DC' },
}
