import cors from '@koa/cors'
import Koa from 'koa'
import bodyParser from 'koa-bodyparser'

import config from './config'
import { logger } from './logger'
import queue from './queue'
import { router } from './router'

const app = new Koa()
const { port } = config()

app.use(queue())
app.use(cors({ origin: '*' }))
app.use(bodyParser())
app.use(router.routes())
app.listen(port)

logger.info(`app listening on http://0.0.0.0:${config.port}`)
