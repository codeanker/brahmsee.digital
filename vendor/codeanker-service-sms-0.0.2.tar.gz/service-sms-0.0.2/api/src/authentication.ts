import type { application } from '@prisma/client'
import type { Context } from 'koa'

import prisma from './prisma'
import { z } from './zod'

const headersSchema = z.object({
  'x-api-key': z.string(),
})

export type AuthenticationResult = { application: application }

export async function authenticate(context: Context) {
  const { 'x-api-key': apiKey } = headersSchema.parse(context.request.headers)
  const application = await prisma.application.findUniqueOrThrow({
    where: {
      token: apiKey,
    },
  })
  return { application }
}
