import path from 'node:path'
import { fileURLToPath } from 'node:url'

import config from 'config'
import { z } from 'zod'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const baseConfig = config.util.loadFileConfigs(path.join(__dirname, '..', 'config'))

const configSchema = z.strictObject({
  redis: z.strictObject({
    host: z.string(),
    port: z.number(),
  }),
  host: z.string(),
  port: z.number(),
  provider: z.object({
    sms_id: z.string(),
    sms_pw: z.string(),
  }),
  postgres: z.string(),
})

export default function () {
  return configSchema.parse(baseConfig)
}
