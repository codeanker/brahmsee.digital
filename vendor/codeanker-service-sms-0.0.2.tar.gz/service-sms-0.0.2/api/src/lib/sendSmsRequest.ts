import axios from 'axios'

import config from '../config'
import applicationTypesEnum from '../enums/applicationTypesEnum'
import prisma from '../prisma'

const targetLink = 'https://sm-http.ic3s.de/cgi-bin/sm-http.pl'

/** Sends the message to the provider */
export async function sendSmsRequest(messageId: number, applicationId: number) {
  const message = await prisma.message.findUniqueOrThrow({
    where: {
      id: messageId,
    },
  })

  const application = await prisma.application.findUniqueOrThrow({
    where: {
      id: applicationId,
    },
  })
  const postData = await buildRequestData(message, application)
  await axios.post(targetLink, postData, {
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
  })

  await prisma.message.update({
    where: {
      id: message.id,
    },
    data: {
      status: 'SENT',
    },
  })
}

function buildRequestData(message: any, application: any) {
  const { provider } = config()
  const _id = provider.sms_id
  const _pw = provider.sms_pw

  let baseString = `id=${_id}&pw=${_pw}&adc=${message.to}&oadc=${message.from}&msg=${message.content}`
  if (message.originator) baseString += `&alnumoadc=${message.originator}`
  if (application.type == applicationTypesEnum.DEV.api) baseString += `&discardmg=1` //TODO: funktioniert nicht

  return baseString
}
