import prisma from '../prisma'

// deletes the user information of a message after the number of subtract days (default: 14 days)
// interval of 1 day

export async function messageDeleteUserInfo() {
  const subtractDays = 14
  const targetDate = new Date()
  targetDate.setDate(targetDate.getDate() - subtractDays)

  const results = await prisma.message.updateMany({
    where: {
      updatedAt: {
        lte: targetDate,
      },
    },
    data: {
      content: '',
      to: '',
    },
  })

  return `Patched messages: ${results.count}`
}

await messageDeleteUserInfo()
