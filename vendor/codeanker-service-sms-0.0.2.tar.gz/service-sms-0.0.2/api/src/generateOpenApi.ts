import { writeFileSync } from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

import { stringify } from 'yaml'
import { createDocument, type ZodOpenApiPathsObject } from 'zod-openapi'

import { toOpenApiRoute, validateUniqueRoutes } from './helpers/defineRoute'
import { routes } from './routes/_routes'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

type OpenApiConfig = {
  title: string
  version: string
  description: string
}

generateOpenApi({
  version: '1.0.0',
  title: 'SMS API',
  description: 'The SMS API',
})

export function generateOpenApi(config: OpenApiConfig) {
  validateUniqueRoutes(routes)
  const paths: ZodOpenApiPathsObject = routes.reduce((paths, route) => {
    return {
      ...paths,
      [route.path]: {
        ...paths[route.path],
        [route.method]: toOpenApiRoute(route),
      },
    }
  }, {})

  const document = createDocument({
    openapi: '3.1.0',
    info: {
      title: config.title,
      version: config.version,
      description: config.description,
    },
    components: {
      securitySchemes: {
        ApiKeyAuth: {
          type: 'apiKey',
          in: 'header',
          name: 'x-api-key',
        },
      },
    },
    servers: [
      {
        url: 'http://example.com/dev',
        description: 'Dev Endpoint',
      },
      {
        url: 'http://example.com/prod',
        description: 'Prod Endpoint',
      },
    ],
    paths: paths,
  })

  const yaml = stringify(document, { aliasDuplicateObjects: false, indent: 2 })
  const json = JSON.stringify(document, null, 2)
  writeFileSync(path.join(__dirname, 'openapi.yml'), yaml)
  writeFileSync(path.join(__dirname, 'openapi.json'), json)
}
