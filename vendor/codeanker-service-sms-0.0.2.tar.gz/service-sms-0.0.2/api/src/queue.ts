import { Queue, Worker } from 'bullmq'

import config from './config'
import { sendSmsRequest } from './lib/sendSmsRequest'

const { redis } = config()
const redisConnection = {
  host: redis.host,
  port: redis.port,
}

type SmsSendQueueJobData = {
  messageId: number
  applicationId: number
}

const queueName = 'smsSendQueue'

const smsSendQueue = new Queue<SmsSendQueueJobData>(queueName, { connection: redisConnection })

function addSmsSendQueueWorker() {
  return new Worker<SmsSendQueueJobData>(
    queueName,
    async (job) => {
      await sendSmsRequest(job.data.messageId, job.data.applicationId)
    },
    { connection: redisConnection }
  )
}

addSmsSendQueueWorker()

async function addSmsSendQueueJob(messageId: number, applicationId: number) {
  const job = await smsSendQueue.add(queueName, { messageId, applicationId })
  //console.log(`Message ${messageId} is in queue with jobId ${job.id}`)
  if (job.id === undefined) throw new Error('Job id is undefined')
  return job.id
}

export default function queue() {
  return async function bodyParser(ctx, next) {
    ctx.addSmsSendQueueJob = addSmsSendQueueJob
    await next()
  }
}
