import crypto from 'crypto'

import applicationTypesEnum from '../../enums/applicationTypesEnum'
import { defineRoute } from '../../helpers/defineRoute'
import PublicError from '../../helpers/PublicError'
import prisma from '../../prisma'
import { z } from '../../zod'

const appTypes = Object.values(applicationTypesEnum).map((entry) => entry.api)

const createAppBodySchema = z.strictObject({
  name: z.string().openapi({ description: 'The name for the application' }),
  isMaster: z
    .boolean()
    .openapi({ description: 'Set if the application should have master permissions' })
    .optional()
    .default(false),
  originator: z
    .array(
      z.object({
        name: z.string(),
        approved: z.boolean().default(false),
      })
    )
    .openapi({ description: 'The originators who can be used' })
    .optional()
    .default([]),
  type: z
    .string()
    .transform((value) => {
      const isValid = appTypes.includes(value)
      if (!isValid) throw new PublicError('Type has an incorrect value')
      return value
    })
    .optional()
    .default(applicationTypesEnum.DEV.api)
    .openapi({ description: 'Determine whether it is a dev or prod app' }),
  tax: z.array(z.string()).optional().default([]).openapi({ description: 'The tax for the app' }),
})

const createAppResultSchema = z.strictObject({
  token: z.string().openapi({ description: 'Your api token' }),
  name: z.string().openapi({ description: 'Your application name' }),
  isMaster: z.boolean().openapi({ description: 'The application has master rights' }),
  originator: z
    .array(
      z.object({
        name: z.string(),
        approved: z.boolean().default(false),
      })
    )
    .openapi({ description: 'The registered originators' }),
  type: z.string().openapi({ description: 'The application type' }),
  tax: z.array(z.string()).openapi({ description: 'The registered tax for the app' }),
})

export const createApplication = defineRoute({
  id: 'createApp',
  summary: 'Create app',
  description: 'Create a new application',
  path: '/create-app',
  method: 'post',
  bodySchema: createAppBodySchema,
  resultSchema: createAppResultSchema,
  protected: true,
  masterProtected: true,
  handler: async ({ body }) => {
    type createDataType = {
      token: string
      name: string
      isMaster: boolean
      originator: { name: string; approved: boolean }[]
      type: string
      tax: string[]
    }

    const createData: createDataType = {
      token: crypto.randomUUID(),
      name: body.name,
      isMaster: body.isMaster,
      originator: body.originator,
      type: body.type,
      tax: body.tax,
    }

    const existingApp = await prisma.application.findFirst({
      where: {
        name: createData.name,
      },
    })

    if (existingApp) {
      throw new PublicError('Application already exists')
    }

    await prisma.application.create({
      data: createData,
      select: {
        token: true,
      },
    })
    return createData
  },
})
