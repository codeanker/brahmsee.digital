import { createApplication } from './createApplication/createApplication'
import { getStats } from './getStats/getStats'
import { sendSms } from './sendSms/sendSms'

export const routes = [sendSms, getStats, createApplication]
