import { defineRoute } from '../../helpers/defineRoute'
import PublicError from '../../helpers/PublicError'
import prisma from '../../prisma'
import { z } from '../../zod'

import { checkIfOriginatorIsApproved } from './helpers/checkIfOriginatorIsApproved'
import { numberOfSmsSent } from './helpers/numberOfSmsSent'
import { parseUmlauts } from './helpers/parseUmlauts'
import { validateMessageLength } from './helpers/validateMessageLength'
import { validatePhoneNumber } from './helpers/validatePhoneNumber'

const bodySchema = z.strictObject({
  from: z.string().openapi({ description: 'The phone number to send the message from' }),
  to: z.string().openapi({ description: 'The phone number to send the message to' }),
  message: z.string().openapi({ description: 'The message to send' }),
  originator: z.string().openapi({ description: 'Name of the originator' }).optional(),
})

const resultSchema = z.strictObject({
  jobId: z.string().openapi({ description: 'The job id' }),
  messageLengthNotice: z
    .string()
    .openapi({ description: 'The length of the message after the special characters have been converted' }),
  numberOfSmsSent: z.union([z.string(), z.number()]).openapi({
    description:
      'The number of SMS in which your message will be sent (153 characters per SMS. Longer messages will be split into a maximum of 4 SMS)',
  }),
})

export const sendSms = defineRoute({
  id: 'sendSms',
  summary: 'Send an SMS',
  description: 'Send an SMS to a phone number',
  path: '/send-sms',
  method: 'post',
  bodySchema: bodySchema,
  resultSchema,
  protected: true,
  masterProtected: false,
  handler: async ({ body, auth, context }) => {
    if (body.originator != null) {
      const approved = await checkIfOriginatorIsApproved(auth.application.originator, body.originator)
      if (!approved) throw new PublicError('Originator is not approved!')
    }

    const fromNumberIsValid = validatePhoneNumber(body.from)
    const toNumberIsValid = validatePhoneNumber(body.to)
    if (!fromNumberIsValid || !toNumberIsValid) throw new PublicError('Invalid phone number format')

    const parsedMessage = await parseUmlauts(body.message)
    const messageLengthNotice = await validateMessageLength(parsedMessage)
    const numberOfSms = await numberOfSmsSent(parsedMessage)

    type createDataType = {
      from: string
      applicationId: number
      to: string
      content: string
      originator?: string | undefined
    }

    const createData: createDataType = {
      from: body.from,
      applicationId: auth.application.id,
      to: body.to,
      content: parsedMessage,
      originator: body.originator != null ? body.originator : undefined,
    }

    const message = await prisma.message.create({
      data: createData,
      select: {
        id: true,
      },
    })

    const jobId = await context.addSmsSendQueueJob(message.id, auth.application.id)
    return {
      jobId: jobId,
      messageLengthNotice: messageLengthNotice,
      numberOfSmsSent: numberOfSms,
    }
  },
})
