export function checkIfOriginatorIsApproved(array, searchName) {
  if (!array || array.length == 0) return false
  return (array.find((item) => item.name === searchName) || {}).approved === true
}
