const phoneRegex = new RegExp(/^(\+|00|0)?(\d{2,4})?[-]?(\d{3,4})[-]?(\d{3,4})$/)

export function validatePhoneNumber(value: string) {
  if (!value) return true
  const phoneNumber = value.replace(/\s/g, '')
  const phoneValid = phoneRegex.test(phoneNumber)
  if (phoneValid) {
    return true
  }
  return false
}
