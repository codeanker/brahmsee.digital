export function validateMessageLength(message) {
  if (message.length <= 153) {
    return `After converting the special characters, the message length is ${message.length} characters and is sent in 1 SMS`
  } else if (message.length > 153 && message.length <= 306) {
    return `After converting the special characters, the message length is ${message.length} characters and is sent in 2 SMS`
  } else if (message.length > 306 && message.length <= 459) {
    return `After converting the special characters, the message length is ${message.length} characters and is sent in 3 SMS`
  } else if (message.length > 459 && message.length <= 612) {
    return `After converting the special characters, the message length is ${message.length} characters and is sent in 4 SMS`
  } else {
    throw new Error(
      `After converting the special characters, the message length is ${message.length} and exceeds the maximum length of 612 characters!`
    )
  }
}
