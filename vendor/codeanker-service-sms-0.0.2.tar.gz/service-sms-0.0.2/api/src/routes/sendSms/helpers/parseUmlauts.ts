import specialCharsEnum from '../../../enums/specialCharsEnums'
import umlautsEnum from '../../../enums/umlautsEnum'

export function parseUmlauts(message) {
  const characterArray = message.split('')
  for (let i = 0; i < characterArray.length; i++) {
    Object.values(umlautsEnum).forEach((umlaut) => {
      if (characterArray[i] === umlaut.api) characterArray[i] = umlaut.human
    })
    Object.values(specialCharsEnum).forEach((specialChar) => {
      if (characterArray[i] === specialChar.api) characterArray[i] = specialChar.human
    })
  }
  const parsedMessage = characterArray.join('')

  return parsedMessage
}
