export function numberOfSmsSent(message) {
  return Math.ceil(message.length / 153)
}
