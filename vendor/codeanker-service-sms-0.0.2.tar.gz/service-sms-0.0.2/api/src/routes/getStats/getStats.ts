import { defineRoute } from '../../helpers/defineRoute'
import PublicError from '../../helpers/PublicError'
import prisma from '../../prisma'
import { z } from '../../zod'

const dateSchema = z.coerce.date()

const getStatsBodySchema = z.strictObject({
  from: z
    .string()
    .openapi({ description: 'From Date' })
    .transform((fromStr) => {
      const date = dateSchema.safeParse(fromStr).success ? new Date(fromStr) : null
      if (date == null) throw new PublicError('Wrong date format. Use MM.DD.YYYY ')
      return date
    }),
  to: z
    .string()
    .openapi({ description: 'To Date (if empty, the current day is taken)' })
    .transform((toStr) => {
      const date = dateSchema.safeParse(toStr).success ? new Date(toStr) : null
      if (date == null) throw new PublicError('Wrong date format. Use MM.DD.YYYY')
      return date
    })
    .optional(),
  // tag: z.string().openapi({}).optional(),
})

const getStatsResultSchema = z.strictObject({
  from: z.date().openapi({ description: 'The start date' }),
  to: z.date().openapi({ description: 'The end date' }),
  totalMessagesCount: z.number().openapi({ description: 'The total amount of sent sms' }),
  sentMessagesCount: z.number().openapi({ description: 'The total amount of SMS sent with the status sent' }),
  pendingMessagesCount: z.number().openapi({ description: 'The total amount of SMS sent with the status pending' }),
})

export const getStats = defineRoute({
  id: 'getStats',
  summary: 'Get message information',
  description: 'Get information about the messages sent by an application',
  path: '/get-stats',
  method: 'get',
  bodySchema: getStatsBodySchema,
  resultSchema: getStatsResultSchema,
  protected: true,
  masterProtected: false,
  handler: async ({ body, auth }) => {
    type messagesType = {
      id: number
      createdAt: Date
      updatedAt: Date
      from: string
      to: string
      content: string
      applicationId: number
      originator: string | null
      status: string
    }

    const fromDate = body.from
    const toDate = body.to != null ? body.to : new Date()
    let messages: messagesType[]

    try {
      messages = await prisma.message.findMany({
        where: {
          applicationId: auth.application.id,
          createdAt: {
            gte: fromDate,
            lte: toDate,
          },
        },
      })
    } catch (error) {
      console.error(error)
      throw new PublicError('Error while get messages in getStats')
    }

    const totalMessagesCount: number = messages.length
    const sentMessagesCount: number = messages.filter((msg) => msg.status === 'SENT').length
    const pendingMessagesCount: number = messages.filter((msg) => msg.status === 'PENDING').length

    return {
      from: fromDate,
      to: toDate,
      totalMessagesCount: totalMessagesCount,
      sentMessagesCount: sentMessagesCount,
      pendingMessagesCount: pendingMessagesCount,
    }
  },
})
