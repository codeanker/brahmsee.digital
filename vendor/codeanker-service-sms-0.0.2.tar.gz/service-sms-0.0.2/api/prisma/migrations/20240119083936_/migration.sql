-- AlterTable
ALTER TABLE "application" ADD COLUMN     "tax" TEXT[] DEFAULT ARRAY[]::TEXT[];
