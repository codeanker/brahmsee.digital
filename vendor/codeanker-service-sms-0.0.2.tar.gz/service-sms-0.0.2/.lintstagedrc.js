module.exports = {
  "*.{js,ts,vue}": ["eslint --cache"]
}
