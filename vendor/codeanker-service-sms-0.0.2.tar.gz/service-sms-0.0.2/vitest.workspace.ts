import { defineWorkspace } from 'vitest/config'

export default defineWorkspace([
  './api/vitest.config.{e2e,unit}.ts',
  './frontend/vitest.config.{e2e,unit,component}.ts',
])
